import{cX as r}from"./main-BonZl4fJ.js";const s={dateStyle:"long",timeStyle:"short"};function c(){const{whoAmI:t}=r();return function(o,e){return o.toLocaleString(t.locale,e)}}export{s as F,c as u};
//# sourceMappingURL=useFormatDate-DGGwO5qK.js.map
