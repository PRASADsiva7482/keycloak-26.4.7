import{cg as o}from"./main-BonZl4fJ.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-CCbit8Ep.js.map
