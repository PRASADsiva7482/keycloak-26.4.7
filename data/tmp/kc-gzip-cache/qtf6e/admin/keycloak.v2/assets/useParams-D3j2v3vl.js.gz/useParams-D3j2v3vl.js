import{c as s}from"./main-BonZl4fJ.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-D3j2v3vl.js.map
